var g_sPRIVATE = "PRIVATE";
var g_sPUBLIC = "PUBLIC";
