
var g_pathname_before_goto_login_page = window.location.pathname + window.location.search;
gotoLoginPageIfAccountCookieNotFound(g_pathname_before_goto_login_page);