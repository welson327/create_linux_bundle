class Esbi::InvestorController < ApplicationController
	def index
	end
end
