class Example::HelloworldController < ApplicationController
	def helloworld
	end
	
end
