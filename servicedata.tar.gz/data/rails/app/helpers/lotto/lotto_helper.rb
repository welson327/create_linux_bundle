module Lotto::LottoHelper
end
