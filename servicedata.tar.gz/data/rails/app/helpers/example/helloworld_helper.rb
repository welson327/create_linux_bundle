module Example::HelloworldHelper
end
