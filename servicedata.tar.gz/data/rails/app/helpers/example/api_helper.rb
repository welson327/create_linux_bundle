module Example::ApiHelper
end
