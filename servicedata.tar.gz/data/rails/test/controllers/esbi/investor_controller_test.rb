require 'test_helper'

class Esbi::InvestorControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
