require 'test_helper'

class Example::ApiControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
