require 'test_helper'

class Example::HelloworldControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
