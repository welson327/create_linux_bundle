require 'test_helper'

class Example::ApiHelperTest < ActionView::TestCase
end
