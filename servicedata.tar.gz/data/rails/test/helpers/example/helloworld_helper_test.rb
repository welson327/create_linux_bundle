require 'test_helper'

class Example::HelloworldHelperTest < ActionView::TestCase
end
