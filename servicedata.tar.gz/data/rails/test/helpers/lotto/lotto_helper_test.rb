require 'test_helper'

class Lotto::LottoHelperTest < ActionView::TestCase
end
