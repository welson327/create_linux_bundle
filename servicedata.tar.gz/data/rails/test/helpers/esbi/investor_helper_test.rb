require 'test_helper'

class Esbi::InvestorHelperTest < ActionView::TestCase
end
