#!/bin/bash

sync; sync; init 6;
