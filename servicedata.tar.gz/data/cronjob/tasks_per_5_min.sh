#!/bin/bash

/yiabiRoot/cronjob/calc_book_statistics.sh

/yiabiRoot/cronjob/check_docserver_suspend.sh
